import tkinter as tk
from tkinter import StringVar

root = tk.Tk()
root.geometry('500x500')

questions = ["1.Python case sensitive when dealing with identifiers?",
             "2.sys.version() functions can help us to find the version of python that we are currently working on?",
             "3.Humans discovered programming languages in the 1940s and have been decoding them ever since",
             "4.Strings are composed of only letters and symbols",
             "5.Python is a interpreted language?",
             "6.Every function created with the def keyword must have at least one parameter.",
             "7.You should not put error messages into help seeking emails because it can clutter up the email.",
             "8.You can nest if statements inside of other if statements, but not inside functions.",
             "9.The Iteration Variable will take on each value of the List Variable, one at a time.",
             "10.The body of a for loop will contain one statement for each element of the iteration list.",
             "11.Like an if statement and a function call, the for Loop might cause the execution to not follow the sequential order of lines.",
             "12.The statement count = count +1 will cause an error because no number can be greater than itself.",
             "13.List comprehensions cannot express everything that a for loop can.",
             "14.Dictionaries will always have at least one key and value pair",
             "15.Dictionaries are useful because you can have duplicate keys.",
             "16.Keys can be added to a dictionary after the dictionary has been created.",
             "17.You can store a dictionary as one of the elements of a list.",
             "18.You can store a list as one of the keys of a dictionary.",
             "19.You can store a list as one of the values of a dictionary.",
             "20.Unlike Lists, Tuples are immutable, meaning Tuples cannot be changed after they are created.",
             ]
options = [['true','false'],['true','false'],['true','false'],['true','false'],['true','false']
           ,['true','false'],['true','false'],['true','false'],['true','false'],['true','false']
           ,['true','false'],['true','false'],['true','false'],['true','false'],['true','false']
           ,['true','false'],['true','false'],['true','false'],['true','false'],['true','false']]


frame = tk.Frame(root, padx=10, pady=10,bg='#82BA41')
question_label = tk.Label(frame,height=5, width=28,bg='grey',fg="#82BA41", 
                          font=('Verdana', 20),wraplength=500)


v1 = StringVar(frame)
v2 = StringVar(frame)

option1 = tk.Radiobutton(frame, bg="#82BA41", variable=v1, font=('Verdana', 20),
                         command = lambda : checkAnswer(option1))
option2 = tk.Radiobutton(frame, bg="#82BA41", variable=v2, font=('Verdana', 20), 
                         command = lambda : checkAnswer(option2))
button_next = tk.Button(frame, text='Next',bg='Orange', font=('Verdana', 20), 
                        command = lambda : displayNextQuestion())

frame.pack(fill="both", expand="true")
question_label.grid(row=0, column=0)

option1.grid(sticky= 'W', row=1, column=0)
option2.grid(sticky= 'W', row=2, column=0)


button_next.grid(row=6, column=0)


index = 0
correct = 0

# create a function to disable radiobuttons
def disableButtons(state):
    option1['state'] = state
    option2['state'] = state


# create a function to check the selected answer
def checkAnswer(radio):
    global correct, index
    
    # the 2th item is the correct answer
    # we will check the user selected answer with the 2th item
    if radio['text'] == options[index][1]:
        correct +=1

    index +=1
    disableButtons('disable')


# create a function to display the next question
def displayNextQuestion():
    global index, correct

    if button_next['text'] == 'Restart The Quiz':
        correct = 0
        index = 0
        question_label['bg'] = 'grey'
        button_next['text'] = 'Next'

    if index == len(options):
       question_label['text'] = str(correct) + " / " + str(len(options))
       button_next['text'] = 'Restart The Quiz'
       if correct >= len(options)/2:
           question_label['bg'] = 'green'
       else:
            question_label['bg'] = 'red'





    else:
        question_label['text'] = questions[index]
        
        disableButtons('normal')
        opts = options[index]
        option1['text'] = opts[0]
        option2['text'] = opts[1]

        v1.set(opts[0])
        v2.set(opts[1])

        if index == len(options) - 1:
            button_next['text'] = 'Check the Results'





displayNextQuestion()

root.mainloop()
import tkinter as tk
from tkinter import StringVar

root = tk.Tk()
root.geometry('500x500')

questions = ["1.Python case sensitive when dealing with identifiers?",
             "2.sys.version() functions can help us to find the version of python that we are currently working on?",
             "3.Humans discovered programming languages in the 1940s and have been decoding them ever since",
             "4.Strings are composed of only letters and symbols",
             "5.Python is a interpreted language?",
             "6.Every function created with the def keyword must have at least one parameter.",
             "7.You should not put error messages into help seeking emails because it can clutter up the email.",
             "8.You can nest if statements inside of other if statements, but not inside functions.",
             "9.The Iteration Variable will take on each value of the List Variable, one at a time.",
             "10.The body of a for loop will contain one statement for each element of the iteration list.",
             "11.Like an if statement and a function call, the for Loop might cause the execution to not follow the sequential order of lines.",
             "12.The statement count = count +1 will cause an error because no number can be greater than itself.",
             "13.List comprehensions cannot express everything that a for loop can.",
             "14.Dictionaries will always have at least one key and value pair",
             "15.Dictionaries are useful because you can have duplicate keys.",
             "16.Keys can be added to a dictionary after the dictionary has been created.",
             "17.You can store a dictionary as one of the elements of a list.",
             "18.You can store a list as one of the keys of a dictionary.",
             "19.You can store a list as one of the values of a dictionary.",
             "20.Unlike Lists, Tuples are immutable, meaning Tuples cannot be changed after they are created.",
             ]
options = [['true','false'],['true','false'],['true','false'],['true','false'],['true','false']
           ,['true','false'],['true','false'],['true','false'],['true','false'],['true','false']
           ,['true','false'],['true','false'],['true','false'],['true','false'],['true','false']
           ,['true','false'],['true','false'],['true','false'],['true','false'],['true','false']]


frame = tk.Frame(root, padx=10, pady=10,bg='#82BA41')
question_label = tk.Label(frame,height=5, width=28,bg='grey',fg="#82BA41", 
                          font=('Verdana', 20),wraplength=500)


v1 = StringVar(frame)
v2 = StringVar(frame)

option1 = tk.Radiobutton(frame, bg="#82BA41", variable=v1, font=('Verdana', 20),
                         command = lambda : checkAnswer(option1))
option2 = tk.Radiobutton(frame, bg="#82BA41", variable=v2, font=('Verdana', 20), 
                         command = lambda : checkAnswer(option2))

button_next = tk.Button(frame, text='Next',bg='Orange', font=('Verdana', 20), 
                        command = lambda : displayNextQuestion())

frame.pack(fill="both", expand="true")
question_label.grid(row=0, column=0)

option1.grid(sticky= 'W', row=1, column=0)
option2.grid(sticky= 'W', row=2, column=0)

button_next.grid(row=6, column=0)


index = 0
correct = 0

# create a function to disable radiobuttons
def disableButtons(state):
    option1['state'] = state
    option2['state'] = state


# create a function to check the selected answer
def checkAnswer(radio):
    global correct, index
    
    # the 2th item is the correct answer
    # we will check the user selected answer with the 2th item
    if radio['text'] == options[index][1]:
        correct +=1

    index +=1
    disableButtons('disable')


# create a function to display the next question
def displayNextQuestion():
    global index, correct

    if button_next['text'] == 'Restart The Quiz':
        correct = 0
        index = 0
        question_label['bg'] = 'grey'
        button_next['text'] = 'Next'

    if index == len(options):
       question_label['text'] = str(correct) + " / " + str(len(options))
       button_next['text'] = 'Restart The Quiz'
       if correct >= len(options)/2:
           question_label['bg'] = 'green'
       else:
            question_label['bg'] = 'red'





    else:
        question_label['text'] = questions[index]
        
        disableButtons('normal')
        opts = options[index]
        option1['text'] = opts[0]
        option2['text'] = opts[1]
        v1.set(opts[0])
        v2.set(opts[1])

        if index == len(options) - 1:
            button_next['text'] = 'Check the Results'





displayNextQuestion()

root.mainloop()
